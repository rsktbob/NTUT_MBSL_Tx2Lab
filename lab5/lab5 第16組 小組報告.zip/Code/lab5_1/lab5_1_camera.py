import subprocess

cmd = "gst-launch-1.0 nvarguscamerasrc ! nvvidconv ! videoconvert ! xvimagesink -e"
subprocess.call(cmd, shell=True)


