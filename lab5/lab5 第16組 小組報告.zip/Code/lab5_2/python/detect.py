import Jetson.GPIO as GPIO
import time

SPICLK = 11
SPIMISO = 9
SPIMOSI = 10
SPICS = 8

output_pin = 7
photo_ch = 0

led_01 = 5
led_02 = 19

def init():
    GPIO.setmode(GPIO.BOARD)
    GPIO.setup(output_pin, GPIO.OUT, initial=GPIO.HIGH)
    GPIO.setwarnings(False)
    GPIO.cleanup()
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(SPIMOSI, GPIO.OUT)
    GPIO.setup(SPIMISO, GPIO.IN)
    GPIO.setup(SPICLK, GPIO.OUT)
    GPIO.setup(SPICS, GPIO.OUT)
    GPIO.setup(led_01, GPIO.OUT, initial=GPIO.LOW)
    GPIO.setup(led_02, GPIO.OUT, initial=GPIO.LOW)

def readadc(adcnum, clockpin, mosipin, misopin, cspin):
    if ((adcnum > 7) or (adcnum < 0)):
        return -1
    GPIO.output(cspin, True)
    GPIO.output(clockpin, False)
    GPIO.output(cspin, False)

    commandout = adcnum
    commandout |= 0x18
    commandout <<= 3
    for i in range(5):
        if (commandout & 0x80):
            GPIO.output(mosipin, True)
        else:
            GPIO.output(mosipin, False)
        commandout <<= 1
        GPIO.output(clockpin, True)
        GPIO.output(clockpin, False)
    adcout = 0
    for i in range(12):
        GPIO.output(clockpin, True)
        GPIO.output(clockpin, False)
        adcout <<= 1
        if (GPIO.input(misopin)):
            adcout |= 0x1
    GPIO.output(cspin, True)
    
    adcout >>= 1
    return adcout

def main():
    init()
    adc_value = readadc(photo_ch, SPICLK, SPIMOSI, SPIMISO, SPICS)
    if adc_value > 500 and adc_value < 800:
        GPIO.output(led_01, True)
        GPIO.output(led_02, False)
    elif adc_value > 800:
        GPIO.output(led_01, False)
        GPIO.output(led_02, True)
    else:
        GPIO.output(led_01, False)
        GPIO.output(led_02, False)
    print(adc_value)

if __name__ == '__main__':
    try:
        main()
    except:
        print()
