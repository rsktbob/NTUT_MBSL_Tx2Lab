const express = require('express');
const bodyParser = require('body-parser');
const { resolve } = require('path');
const app = express();
const port = 3000;

function detect(){
  return new Promise(function(resolve, reject) {
    let child_process = require("child_process");

    let process = child_process.spawn('python', [
      "./python/detect.py"
    ]);
  
    process.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`);
      resolve(data)
    });

    process.stderr.on(`data`, (data) => {
      console.error(`stderr: ${data}`);
      reject(data)
    });
  });
}

function controlLED(LED, POWER) {;
  let child_process = require("child_process");

  let process = child_process.execFile('sudo',["./c++/gpio", LED, POWER]);

  process.stdout.on('data',(data) => {
      console.log(`stdout: ${data}`);
  });
  process.stdout.on('data', (data) => {
      console.error(`stderr ${data}`);
  });
}

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', function(req, res) {
  res.sendFile(__dirname + '/public/index.html');
});

app.post('/detect_selected', function(req, res) {
    const detect_mode = req.body.detect_mode;
    if (detect_mode == 'detect') {
      res.sendFile(__dirname + '/public/detect.html');
    } else if (detect_mode == 'no_detect') {
      res.sendFile(__dirname + '/public/no_detect.html');
    }
    else {
        res.sendFile(__dirname + '/public/detect.html');
    }
});

app.get('/detect', async function(req, res) {
  try {
    const result = await detect();
    res.send(result);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.get("/control_led", (req,res)=>{
  let led_control = req.query.led_control;
  console.log(req.query)
  if (led_control == 'ON'){
    if (req.query.LED1 == "on"){
      controlLED("LED1", "ON");
    }
    if (req.query.LED2 == "on"){
      controlLED("LED2", "ON");
    }
  }
  else{
    if (req.query.LED1 == "on"){
      controlLED("LED1", "OFF");
    }
    if (req.query.LED2 == "on"){
      controlLED("LED2", "OFF");
    }
  }

  res.sendFile(__dirname + '/public/no_detect.html');
})

app.get("/shine_led", (req)=>{
  controlLED("Shine", req.query.times);
})

app.listen(port, () => console.log(`Server listening on port ${port}!`));
