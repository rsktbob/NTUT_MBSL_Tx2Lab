#include <errno.h>
#include <fcntl.h>
#include <iostream>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace std;

map<int, int> led_id_to_gpio = {{1, 255}, {2, 429}, {3, 398}, {4, 389}};

int gpio_export(unsigned int gpio) {
  int fd, len;
  char buf[64];
  fd = open("/sys/class/gpio/export", O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  len = snprintf(buf, sizeof(buf), "%d", gpio);
  write(fd, buf, len);
  return 0;
}

int gpio_unexport(unsigned int gpio) {
  int fd, len;
  char buf[64];
  fd = open("/sys/class/gpio/unexport", O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  len = snprintf(buf, sizeof(buf), "%d", gpio);
  write(fd, buf, len);
  return 0;
}

int gpio_set_dir(unsigned int gpio, string dirStatus) {
  int fd;
  char buf[64];

  snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/direction", gpio);

  fd = open(buf, O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  if (dirStatus == "out") write(fd, "out", 4);
  else write(fd, "in", 3);

  close(fd);
  return 0;
}

int gpio_set_value(unsigned int gpio, int value) {
  int fd;
  char buf[64];

  snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);

  fd = open(buf, O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  if (value == 0) write(fd, "0", 2);
  else write(fd, "1", 2);

  close(fd);
  return 0;
}

void turn_on_led(int led_id) {
  int gpio = led_id_to_gpio[led_id];
  gpio_export(gpio);
  gpio_set_dir(gpio, "out");
  gpio_set_value(gpio, 1);
  printf("ON: LED%d %d\n", led_id, gpio);
}

void turn_off_led(int led_id) {
  int gpio = led_id_to_gpio[led_id];
  gpio_set_value(gpio, 0);
  gpio_unexport(gpio);
  printf("OFF: LED%d %d\n", led_id, gpio);
}

int main(int argc, char* argv[]) {
  int input;

  if (argv[1][0] == 'L' && argv[1][1] == 'E' && argv[1][2] == 'D') {
    int led_id = argv[1][3] - '0';

    if (argv[2][0] == 'O' && argv[2][1] == 'N') {
      turn_on_led(led_id);
    } else {
      turn_off_led(led_id);
    }
  } else {
    for (int led_id = 0; led_id >= 4; led_id++) turn_off_led(led_id);

    int cycle_no = argv[2][0] - '0';
    for (int i = 0; i < cycle_no; i++) {
      int led_to_light_up[2];
      int odd_leds[2] = {1, 2};
      int even_leds[2] = {3, 4};

      // https://stackoverflow.com/a/28008133
      memcpy(led_to_light_up, (i % 2) == 0 ? odd_leds : even_leds, sizeof led_to_light_up);

      for (auto led_id : led_to_light_up) turn_on_led(led_id);
      sleep(1);
      for (auto led_id : led_to_light_up) turn_off_led(led_id);

      printf("\n");
    }
  }
}