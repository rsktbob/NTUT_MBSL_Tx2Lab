#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    bulb_dark = QPixmap("bulb_dark.png");
    bulb_light = QPixmap("bulb_light.png");
    timer = nullptr;
    isFrontLight = true;
    times = 0;
    ui->setupUi(this);
    ui->LED_1->setPixmap(bulb_dark);
    ui->LED_2->setPixmap(bulb_dark);
    ui->LED_3->setPixmap(bulb_dark);
    ui->LED_4->setPixmap(bulb_dark);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_LED_Swiching_clicked()
{
    delete timer;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    timer->start(1000);
    times = ui->Times_input->text().toInt();
}

void MainWindow::update()
{
    if (times > 0)
    {
        if (isFrontLight)
        {
            ui->LED_1->setPixmap(bulb_light);
            ui->LED_2->setPixmap(bulb_light);
            ui->LED_3->setPixmap(bulb_dark);
            ui->LED_4->setPixmap(bulb_dark);
            ui->LED_Checked_1->setChecked(true);
            ui->LED_Checked_2->setChecked(true);
            ui->LED_Checked_3->setChecked(false);
            ui->LED_Checked_4->setChecked(false);
            isFrontLight = false;
        }
        else
        {
            ui->LED_1->setPixmap(bulb_dark);
            ui->LED_2->setPixmap(bulb_dark);
            ui->LED_3->setPixmap(bulb_light);
            ui->LED_4->setPixmap(bulb_light);
            ui->LED_Checked_1->setChecked(false);
            ui->LED_Checked_2->setChecked(false);
            ui->LED_Checked_3->setChecked(true);
            ui->LED_Checked_4->setChecked(true);
            isFrontLight = true;
        }
        times -= 1;
    }
    else
    {
        delete timer;
        timer = nullptr;
        isFrontLight = true;
        ui->LED_1->setPixmap(bulb_dark);
        ui->LED_2->setPixmap(bulb_dark);
        ui->LED_3->setPixmap(bulb_dark);
        ui->LED_4->setPixmap(bulb_dark);
        ui->LED_Checked_1->setChecked(false);
        ui->LED_Checked_2->setChecked(false);
        ui->LED_Checked_3->setChecked(false);
        ui->LED_Checked_4->setChecked(false);
    }
}

void MainWindow::on_LED_Shining_clicked()
{
    delete timer;
    timer = nullptr;
    if (ui->LED_Checked_1->isChecked())
    {
        ui->LED_1->setPixmap(bulb_light);
    }
    else
    {
        ui->LED_1->setPixmap(bulb_dark);
    }
    if (ui->LED_Checked_2->isChecked())
    {
        ui->LED_2->setPixmap(bulb_light);
    }
    else
    {
        ui->LED_2->setPixmap(bulb_dark);
    }
    if (ui->LED_Checked_3->isChecked())
    {
        ui->LED_3->setPixmap(bulb_light);
    }
    else
    {
        ui->LED_3->setPixmap(bulb_dark);
    }
    if (ui->LED_Checked_4->isChecked())
    {
        ui->LED_4->setPixmap(bulb_light);
    }
    else
    {
        ui->LED_4->setPixmap(bulb_dark);;
    }
}
