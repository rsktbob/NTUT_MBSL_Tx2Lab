#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_LED_Swiching_clicked();
    void update();

    void on_LED_Shining_clicked();

private:
    Ui::MainWindow *ui;
    QTimer* timer;
    QPixmap bulb_dark;
    QPixmap bulb_light;
    int times;
    bool isFrontLight;
};

#endif // MAINWINDOW_H
