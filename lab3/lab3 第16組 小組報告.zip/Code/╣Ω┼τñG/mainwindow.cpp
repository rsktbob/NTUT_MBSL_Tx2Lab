#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QTimer>
#include <QKeyEvent>
#include <QDebug>
#include <errno.h>
#include <fcntl.h>
#include <iostream>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace std;

map<int, int> led_id_to_gpio = {{1, 255}, {2, 429}, {3, 398}, {4, 389}};

int gpio_export(unsigned int gpio) {
  int fd, len;
  char buf[64];
  fd = open("/sys/class/gpio/export", O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  len = snprintf(buf, sizeof(buf), "%d", gpio);
  write(fd, buf, len);
  return 0;
}

int gpio_unexport(unsigned int gpio) {
  int fd, len;
  char buf[64];
  fd = open("/sys/class/gpio/unexport", O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  len = snprintf(buf, sizeof(buf), "%d", gpio);
  write(fd, buf, len);
  return 0;
}

int gpio_set_dir(unsigned int gpio, string dirStatus) {
  int fd;
  char buf[64];

  snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/direction", gpio);

  fd = open(buf, O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  if (dirStatus == "out") write(fd, "out", 4);
  else write(fd, "in", 3);

  close(fd);
  return 0;
}

int gpio_set_value(unsigned int gpio, int value) {
  int fd;
  char buf[64];

  snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);

  fd = open(buf, O_WRONLY);

  if (fd < 0) {
    perror("gpio/export");
    return fd;
  }

  if (value == 0) write(fd, "0", 2);
  else write(fd, "1", 2);

  close(fd);
  return 0;
}

void turn_on_led(int led_id) {
  int gpio = led_id_to_gpio[led_id];
  gpio_export(gpio);
  gpio_set_dir(gpio, "out");
  gpio_set_value(gpio, 1);
}

void turn_off_led(int led_id) {
  int gpio = led_id_to_gpio[led_id];
  gpio_set_value(gpio, 0);
  gpio_unexport(gpio);
}

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    bulb_dark = QPixmap("bulb_dark.png");
    bulb_light = QPixmap("bulb_light.png");
    isFrontLight = true;
    isPressOn = false;
    ui->setupUi(this);
    timer = nullptr;
    ui->LED_1->setPixmap(bulb_dark);
    ui->LED_2->setPixmap(bulb_dark);
    ui->LED_3->setPixmap(bulb_dark);
    ui->LED_4->setPixmap(bulb_dark);
    for (int led_id = 1; led_id <= 4; led_id++) turn_off_led(led_id);
    setFocusPolicy(Qt::StrongFocus);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_LED_Shining_clicked()
{
    if (!isPressOn)
    {
        if (ui->LED_Check_1->isChecked())
        {
            ui->LED_1->setPixmap(bulb_light);
            turn_on_led(1);
        }
        else
        {
            ui->LED_1->setPixmap(bulb_dark);
            turn_off_led(1);
        }
        if (ui->LED_Check_2->isChecked())
        {
            ui->LED_2->setPixmap(bulb_light);
            turn_on_led(2);
        }
        else
        {
            ui->LED_2->setPixmap(bulb_dark);
            turn_off_led(2);
        }
        if (ui->LED_Check_3->isChecked())
        {
            ui->LED_3->setPixmap(bulb_light);
            turn_on_led(3);
        }
        else
        {
            ui->LED_3->setPixmap(bulb_dark);
            turn_off_led(3);
        }
        if (ui->LED_Check_4->isChecked())
        {
            ui->LED_4->setPixmap(bulb_light);
            turn_on_led(4);
        }
        else
        {
            ui->LED_4->setPixmap(bulb_dark);
            turn_off_led(4);
        }
    }
}

void MainWindow::on_Switching_On_clicked()
{
    delete timer;
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
    timer->start(ui->horizontalSlider->value()*20);
    isPressOn = true;
}

void MainWindow::update()
{
    if (isFrontLight)
    {
        ui->LED_1->setPixmap(bulb_light);
        ui->LED_2->setPixmap(bulb_light);
        ui->LED_3->setPixmap(bulb_dark);
        ui->LED_4->setPixmap(bulb_dark);
        ui->LED_Check_1->setChecked(true);
        ui->LED_Check_2->setChecked(true);
        ui->LED_Check_3->setChecked(false);
        ui->LED_Check_4->setChecked(false);
        for (int led_id = 1; led_id <= 2; led_id++) turn_on_led(led_id);
        for (int led_id = 3; led_id <= 4; led_id++) turn_off_led(led_id);
        isFrontLight = false;
    }
    else
    {
        ui->LED_1->setPixmap(bulb_dark);
        ui->LED_2->setPixmap(bulb_dark);
        ui->LED_3->setPixmap(bulb_light);
        ui->LED_4->setPixmap(bulb_light);
        ui->LED_Check_1->setChecked(false);
        ui->LED_Check_2->setChecked(false);
        ui->LED_Check_3->setChecked(true);
        ui->LED_Check_4->setChecked(true);
        for (int led_id = 1; led_id <= 2; led_id++) turn_off_led(led_id);
        for (int led_id = 3; led_id <= 4; led_id++) turn_on_led(led_id);
        isFrontLight = true;
    }
}

void MainWindow::on_Switching_Off_clicked()
{
    isFrontLight = true;
    isPressOn = false;
    ui->LED_1->setPixmap(bulb_dark);
    ui->LED_2->setPixmap(bulb_dark);
    ui->LED_3->setPixmap(bulb_dark);
    ui->LED_4->setPixmap(bulb_dark);
    ui->LED_Check_1->setChecked(false);
    ui->LED_Check_2->setChecked(false);
    ui->LED_Check_3->setChecked(false);
    ui->LED_Check_4->setChecked(false);
    for (int led_id = 1; led_id <= 4; led_id++) turn_off_led(led_id);
    delete timer;
    timer = nullptr;
}

void MainWindow::on_horizontalSlider_valueChanged(int value)
{
    if (isPressOn)
    {
        delete timer;
        timer = new QTimer(this);
        connect(timer, SIGNAL(timeout()), this, SLOT(update()));
        timer->start(value*20);
    }
}

void MainWindow::keyPressEvent(QKeyEvent* event)
{
    if (event->key() == Qt::Key_Left)
    {
        ui->horizontalSlider->setSliderPosition(ui->horizontalSlider->sliderPosition() - 1);
    }
    else if (event->key() == Qt::Key_Right)
    {
        ui->horizontalSlider->setSliderPosition(ui->horizontalSlider->sliderPosition() + 1);
    }
}





