#include <errno.h>
#include <fcntl.h>
#include <iostream>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>

using namespace std;

pthread_mutex_t mutex;

int led_id_to_gpio[4] = {255, 254, 298, 389};
int ledState[4] = {};

//396, 466, 427, 389

int gpio_export(unsigned int gpio)
{
    int fd, len;
    char buf[64];
    fd = open("/sys/class/gpio/export", O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    len = snprintf(buf, sizeof(buf), "%d", gpio);
    write(fd, buf, len);
    return 0;
}

int gpio_unexport(unsigned int gpio)
{
    int fd, len;
    char buf[64];
    fd = open("/sys/class/gpio/unexport", O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    len = snprintf(buf, sizeof(buf), "%d", gpio);
    write(fd, buf, len);
    return 0;
}

int gpio_set_dir(unsigned int gpio, string dirStatus)
{
    int fd;
    char buf[64];

    snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/direction", gpio);

    fd = open(buf, O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    if (dirStatus == "out")
        write(fd, "out", 4);
    else
        write(fd, "in", 3);

    close(fd);
    return 0;
}

int gpio_set_value(unsigned int gpio, int value)
{
    int fd;
    char buf[64];

    snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);

    fd = open(buf, O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    if (value == 0)
        write(fd, "0", 2);
    else
        write(fd, "1", 2);

    close(fd);
    return 0;
}

void turn_on_led(int led_id)
{
    int gpio = led_id_to_gpio[led_id];
    gpio_export(gpio);
    gpio_set_dir(gpio, "out");
    gpio_set_value(gpio, 1);
    gpio_unexport(gpio);
    printf("ON: LED%d %d\n", led_id, gpio);
}

void turn_off_led(int led_id)
{
    int gpio = led_id_to_gpio[led_id];
    gpio_export(gpio);
    gpio_set_dir(gpio, "out");
    gpio_set_value(gpio, 0);
    gpio_unexport(gpio);
    printf("OFF: LED%d %d\n", led_id, gpio);
}

void control_led(int led_id, int state)
{
    if (state == 0)
    {
        turn_off_led(led_id);
    }
    else if (state == 1)
    {
        turn_on_led(led_id);
    }
}

void *threadFunctionA(void *arg)
{
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < *(int *)arg; i++)
    {
        cout << "functionA" << endl;
        ledState[0] = 1;
        ledState[1] = 1;
        ledState[2] = 0;
        ledState[3] = 0;
        for (int i = 0; i < 4; i++)
        {
            cout << ledState[i];
            control_led(i, ledState[i]);
        }
        cout << endl;
        sleep(1);
        ledState[0] = 0;
        ledState[1] = 0;
        ledState[2] = 1;
        ledState[3] = 1;
        for (int i = 0; i < 4; i++)
        {
            cout << ledState[i];
            control_led(i, ledState[i]);
        }
        cout << endl;
        sleep(1);
    }
    pthread_mutex_unlock(&mutex);
}

void *threadFunctionB(void *arg)
{
    pthread_mutex_lock(&mutex);
    for (int i = 0; i < *(int *)arg; i++)
    {

        cout << "functionB" << endl;
        ledState[0] = 1;
        ledState[1] = 0;
        ledState[2] = 1;
        ledState[3] = 0;
        for (int i = 0; i < 4; i++)
        {
            cout << ledState[i];
            control_led(i, ledState[i]);
        }
        cout << endl;
        sleep(1);
        ledState[0] = 0;
        ledState[1] = 0;
        ledState[2] = 0;
        ledState[3] = 0;
        for (int i = 0; i < 4; i++)
        {
            cout << ledState[i];
            control_led(i, ledState[i]);
        }
        cout << endl;
        sleep(1);
    }
    pthread_mutex_unlock(&mutex);
}

int main(int argc, char *argv[])
{
    pthread_t thread;
    pthread_mutex_init(&mutex, NULL);
    pthread_mutex_lock(&mutex);

    int times = argv[1][0] - '0';
    pthread_t threads[2];
    pthread_create(&threads[0], NULL, threadFunctionA, (void *)&times);
    pthread_create(&threads[1], NULL, threadFunctionB, (void *)&times);
    pthread_mutex_unlock(&mutex);
    for (int i = 0; i < 2; i++)
    {
        pthread_join(threads[i], NULL);
    }
    pthread_mutex_destroy(&mutex);
    return 0;
}

