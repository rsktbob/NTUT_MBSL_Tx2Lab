#include <errno.h>
#include <fcntl.h>
#include <iostream>
#include <map>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace std;

map<int, int> led_id_to_gpio = {{1, 255}, {2, 254}, {3, 396}, {4, 389}};

void setGPIO(unsigned int gpio, string status)
{
    int io = open("/dev/demo", O_WRONLY);
    if (io < 0)
    {
        perror("gpio error");
        return;
    }
    char buf[10] = {0};
    int led_state = status == "on" ? 1 : 0;
    sprintf(buf, "%d %d", gpio, led_state);
    cout << buf << endl;
    write(io, buf, 6);
    close(io);
    return;
}

void readGPIO(unsigned int led_id)
{
    int io = open("/dev/demo", O_RDONLY);
    if (io < 0)
    {
        perror("gpio error");
        return;
    }
    int gpio = led_id_to_gpio[led_id];
    char buf[2] = {0};
    sprintf(buf, "%d", led_id);
    int status = read(io, buf, sizeof(buf));
    cout << "input: " << gpio << endl;
    cout << "LED" << led_id << "(GPIO=" << gpio << ") Status: " << status << endl;
    close(io);
    return;
}

int gpio_export(unsigned int gpio)
{
    int fd, len;
    char buf[64];
    fd = open("/sys/class/gpio/export", O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    len = snprintf(buf, sizeof(buf), "%d", gpio);
    write(fd, buf, len);
    return 0;
}

int gpio_unexport(unsigned int gpio)
{
    int fd, len;
    char buf[64];
    fd = open("/sys/class/gpio/unexport", O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    len = snprintf(buf, sizeof(buf), "%d", gpio);
    write(fd, buf, len);
    return 0;
}

int gpio_set_dir(unsigned int gpio, string dirStatus)
{
    int fd;
    char buf[64];

    snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/direction", gpio);

    fd = open(buf, O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    if (dirStatus == "out")
        write(fd, "out", 4);
    else
        write(fd, "in", 3);

    close(fd);
    return 0;
}

int gpio_set_value(unsigned int gpio, int value)
{
    int fd;
    char buf[64];

    snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);

    fd = open(buf, O_WRONLY);

    if (fd < 0)
    {
        perror("gpio/export");
        return fd;
    }

    if (value == 0)
        write(fd, "0", 2);
    else
        write(fd, "1", 2);

    close(fd);
    return 0;
}

void turn_on_led(int led_id)
{
    int gpio = led_id_to_gpio[led_id];
    gpio_export(gpio);
    gpio_set_dir(gpio, "out");
    gpio_set_value(gpio, 1);
    gpio_unexport(gpio);
    printf("ON: LED%d %d\n", led_id, gpio);
}

void turn_off_led(int led_id)
{
    int gpio = led_id_to_gpio[led_id];
    gpio_export(gpio);
    gpio_set_dir(gpio, "out");
    gpio_set_value(gpio, 0);
    gpio_unexport(gpio);
    printf("OFF: LED%d %d\n", led_id, gpio);
}

int main(int argc, char *argv[])
{
    int input;
    int led_id = argv[1][3] - '0';
    if (argc == 3)
    {
        if (argv[2][0] == 'o' && argv[2][1] == 'n')
        {
	    printf("%d\n", led_id);
            turn_on_led(led_id);
            setGPIO(led_id_to_gpio[led_id], "on");
        }
        else
        {
	    printf("%d\n", led_id);
            turn_off_led(led_id);
            setGPIO(led_id_to_gpio[led_id], "off");
        }
    }
    else {
        readGPIO(led_id);
    }
}

