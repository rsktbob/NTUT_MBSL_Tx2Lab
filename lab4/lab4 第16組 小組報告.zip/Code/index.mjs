import { createServer } from "http"
import { readFile } from "fs/promises"
import { dirname, resolve } from "path"
import { fileURLToPath } from "url"
import { execFile as execFile_callback } from "child_process"
import { promisify } from "util"
import { appendFile, unlink } from "fs/promises"
import { createTransport } from "nodemailer"

const execFile = promisify(execFile_callback)

async function log(message) {
  message = message.trim() + "\n"
  console.log(message)
  await appendFile(log_path, message)
}

const port = 80
const current_directory = dirname(fileURLToPath(import.meta.url))
const log_filename = "gpio.log"
const log_path = resolve(current_directory, log_filename)
const gpio_path = resolve(current_directory, "bin", "gpio")
const html_path = resolve(current_directory, "index.html")

await unlink(log_path)

createServer(async (request, response) => {
  const { url, method } = request
  await log(`REQUEST: ${JSON.stringify({ url, method })}`)

  if (url == "/" || url == "/index.html") {
    response.end(await readFile(html_path))
  }

  if (url.startsWith("/led/")) {
    const { led_id } = url.match(/^\/led\/(?<led_id>\d)\/?$/).groups
    const { stdout } = await execFile("sudo", [gpio_path, `LED${led_id}`, method === "PUT" ? "ON" : "OFF"])
    await log(stdout)
  }

  if (url.startsWith("/make_shine/")) {
    const { shine_count } = url.match(/^\/make_shine\/(?<shine_count>\d)\/?$/).groups
    const { stdout } = await execFile("sudo", [gpio_path, "make_shine", shine_count])
    await log(stdout)
    await log("Switch End")
  }

  response.status = 200
  response.end()
}).listen(port, async () => {
  await log(`Server is running on port ${port}`)
})

process.on("SIGINT", async () => {
  await log("Server is down")

  const transporter = createTransport({
    service: "Gmail",
    auth: {
      user: "t110590045@gmail.com",
      pass: "bbfvlwcstpetwlfi",
    },
  })

  // https://github.com/nodemailer/nodemailer/issues/759#issuecomment-292861074
  await promisify(transporter.sendMail).bind(transporter)({
    from: "t110590045@gmail.com",
    to: "t110590045@ntut.org.tw",
    subject: `Server log ${new Date().toLocaleString()}`,
    attachments: [
      {
        filename: log_filename,
        content: await readFile(log_path),
      },
    ],
  })

  process.exit()
})

// sudo snap install node --classic --channel=18
// export PATH=/snap/node/current/bin:$PATH
// npm start
